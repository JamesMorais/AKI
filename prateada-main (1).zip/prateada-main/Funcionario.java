package Salao.Beleza;

public class Funcionario   {
//relacionar o funcionario com o tipo de servico que sera feito


    private String nome;


    public Funcionario(String nome) {
        this.nome = nome;

    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getNome() {
        return nome;
    }
}
